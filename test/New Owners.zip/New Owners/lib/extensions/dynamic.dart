extension NumberParsing on dynamic {
  double toDouble() {
    return double.parse(this);
  }
}