import 'package:flutter/material.dart';
import 'package:fuodz/constants/app_colors.dart';
import 'package:fuodz/models/vendor_type.dart';
import 'package:fuodz/view_models/vendor/popular_services.vm.dart';
import 'package:fuodz/widgets/buttons/custom_outline_button.dart';
import 'package:fuodz/widgets/custom_masonry_grid_view.dart';
import 'package:fuodz/widgets/list_items/grid_view_service.list_item.dart';
import 'package:stacked/stacked.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:fuodz/translations/vendor/services.i18n.dart';

class PopularServicesView extends StatelessWidget {
  const PopularServicesView(this.vendorType, {Key key}) : super(key: key);

  final VendorType vendorType;

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PopularServicesViewModel>.reactive(
      viewModelBuilder: () => PopularServicesViewModel(
        context,
        vendorType,
      ),
      onModelReady: (vm) => vm.initialise(),
      builder: (context, vm, child) {
        return VStack(
          [
            //
            ("Popular".i18n + " ${vendorType.name}")
                .text
                .xl
                .semiBold
                .make()
                .p12(),
            CustomMasonryGridView(
              isLoading: vm.isBusy,
              crossAxisSpacing: 10,
              mainAxisSpacing: 20,
              childAspectRatio: 1.1,
              items: List.generate(
                vm.services.length ?? 0,
                (index) {
                  final service = vm.services[index];
                  return GridViewServiceListItem(
                    service: service,
                    onPressed: vm.serviceSelected,
                  );
                },
              ),
            ).p12(),

            //view more
            CustomOutlineButton(
              child: "View More".i18n.text.medium.xl.color(AppColor.primaryColor).makeCentered(),
              titleStyle: context.textTheme.bodyText1.copyWith(
                color: AppColor.primaryColor,
              ),
              onPressed: vm.openSearch,
            ).px20(),
          ],
        ).py12();
      },
    );
  }
}
